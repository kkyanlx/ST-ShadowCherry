# ✦ Shadow Cherry

*影色のさくらんぼ · fog, ash & porcelain rose*

Тема для [SillyTavern](https://github.com/SillyTavern/SillyTavern) поверх [Moonlit Echoes](https://github.com/RivelleDays/SillyTavern-MoonlitEchoesTheme): туманный лес, пепел и фарфоровая роза.

by **ewwn1h** ♡

---

## Что внутри

- **Свои иконки** верхней панели и поля ввода: канделябр, перо, компас, сосны, искры, камея, призрак-кот, мотылёк с хвостами.
- **Шрифты**: имена фрактурой (UnifrakturMaguntia), текст и курсив Spectral, служебное Special Elite.
- **Рамки аватарок**: в Ripple персонаж в Камее, вы в Картуше, в остальных стилях круглая ава в Прицеле.
- **HUD-уголки** у сообщений, разделитель `✧ ✦ ✧`, речь с фарфоровым свечением, жирный с розовым маркером.
- **Свайпы** `‹ prev  [ 1/2 ]  next ›` машинописью.
- **Думалка «Туман»**: подпись меняется по состоянию, мысли в дымке, высота ограничена.
- **Атмосфера**: плывущий туман и пылинки, всё настраивается.

## Установка

1. Нужен **Moonlit Echoes**. Если его нет: Extensions → Install extension →
   `https://github.com/RivelleDays/SillyTavern-MoonlitEchoesTheme`
2. Установите Shadow Cherry так же, по ссылке:
   `https://github.com/kkyanlx/ST-ShadowCherry`
3. **User Settings** → импорт темы → `Shadow Cherry.json`.
4. **Extensions → Moonlit Echoes** → импорт пресета → `[Moonlit] Shadow Cherry.json`.
5. **Backgrounds** → загрузите фон: `Shadow Cherry - Fog Pines.jpg` для ПК, `Shadow Cherry - Fog Branches (mobile).jpg` для телефона.
6. Стиль чата: **Ripple** (для больших портретов в рамках) или Echo / Whisper.

> Пресет Moonlit отвечает только за цвета и размеры. Само оформление подключает это расширение,
> поэтому поле Raw Custom CSS в Moonlit пустое, так и должно быть.

## Настройки

**Extensions → ✦ Shadow Cherry**

| | |
|---|---|
| Оформление темы | включает и выключает весь стиль |
| Туман · плотность | дымка между фоном и чатом |
| Туман · поверх чата | та же дымка, но над перепиской, мягче |
| Пылинки · количество | мелкие частицы в воздухе |

Если в SillyTavern или в системе включено «меньше анимаций», туман и пылинки замирают.
Когда вкладка свёрнута, анимация стоит на паузе. На телефоне частиц вдвое меньше.

## Обновление

Extensions → Manage extensions → обновить Shadow Cherry. Пресеты переимпортировать не нужно.

---

## English

A SillyTavern theme on top of Moonlit Echoes: foggy forest, ash and porcelain rose.
Install Moonlit Echoes, install this extension from `https://github.com/kkyanlx/ST-ShadowCherry`, import `Shadow Cherry.json`
(User Settings) and `[Moonlit] Shadow Cherry.json` (Moonlit Echoes), pick a background
(`Shadow Cherry - Fog Pines.jpg` / `… Fog Branches (mobile).jpg`). Fog and dust live under Extensions → ✦ Shadow Cherry and respect
“reduced motion”. Character names use a blackletter font without Cyrillic.

Fonts: UnifrakturMaguntia, Spectral, Cormorant Garamond, Manrope, PT Mono, Special Elite (Google Fonts, SIL OFL).
